package com.openai.r8ble;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 1001;
    private static final int REQ_EXPORT = 1002;
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Handler main = new Handler(Looper.getMainLooper());
    private final StringBuilder log = new StringBuilder();
    private final Map<String, BluetoothDevice> devices = new LinkedHashMap<>();
    private final List<BluetoothGattCharacteristic> characteristics = new ArrayList<>();

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothDevice selectedDevice;
    private BluetoothGattCharacteristic selectedCharacteristic;

    private TextView status;
    private TextView selectedCharView;
    private TextView logView;
    private ArrayAdapter<String> deviceAdapter;
    private ArrayAdapter<String> charAdapter;
    private EditText hexInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager.getAdapter();
        if (adapter != null) scanner = adapter.getBluetoothLeScanner();
        buildUi();
        ensurePermissions();
        append("R8 BLE Configurator v0.1 ready. Target device name: R8-US");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(12);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("R8 BLE Configurator");
        title.setTextSize(24f);
        root.addView(title);

        status = new TextView(this);
        status.setText("Disconnected");
        status.setTextSize(16f);
        root.addView(status);

        LinearLayout row1 = row();
        Button scan = button("Scan R8-US");
        Button disconnect = button("Disconnect");
        row1.addView(scan, weight());
        row1.addView(disconnect, weight());
        root.addView(row1);

        TextView devicesLabel = label("Discovered devices — tap to connect");
        root.addView(devicesLabel);
        ListView deviceList = new ListView(this);
        deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        deviceList.setAdapter(deviceAdapter);
        deviceList.setMinimumHeight(dp(130));
        root.addView(deviceList, new LinearLayout.LayoutParams(-1, dp(150)));

        LinearLayout row2 = row();
        Button bond = button("Bond selected device");
        Button mtu = button("Request MTU 247");
        row2.addView(bond, weight());
        row2.addView(mtu, weight());
        root.addView(row2);

        root.addView(label("GATT characteristics — tap one to select"));
        ListView charList = new ListView(this);
        charAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        charList.setAdapter(charAdapter);
        charList.setMinimumHeight(dp(220));
        root.addView(charList, new LinearLayout.LayoutParams(-1, dp(260)));

        selectedCharView = new TextView(this);
        selectedCharView.setText("Selected characteristic: none");
        root.addView(selectedCharView);

        LinearLayout row3 = row();
        Button read = button("Read");
        Button notify = button("Subscribe");
        row3.addView(read, weight());
        row3.addView(notify, weight());
        root.addView(row3);

        hexInput = new EditText(this);
        hexInput.setHint("HEX bytes, e.g. 01 FF 0A");
        hexInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(hexInput);

        LinearLayout row4 = row();
        Button writeResp = button("Write HEX");
        Button writeNoResp = button("Write HEX (no response)");
        row4.addView(writeResp, weight());
        row4.addView(writeNoResp, weight());
        root.addView(row4);

        TextView warning = new TextView(this);
        warning.setText("Raw write is for commands you have identified. Unknown controller values can change braking, current, voltage or protection behaviour. Do not guess bytes.");
        root.addView(warning);

        LinearLayout row5 = row();
        Button dump = button("Read all readable");
        Button export = button("Export log");
        row5.addView(dump, weight());
        row5.addView(export, weight());
        root.addView(row5);

        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        logView.setTextSize(12f);
        root.addView(logView);

        setContentView(scroll);

        scan.setOnClickListener(v -> startScan());
        disconnect.setOnClickListener(v -> disconnectGatt());
        bond.setOnClickListener(v -> bondSelected());
        mtu.setOnClickListener(v -> requestMtu());
        read.setOnClickListener(v -> readSelected());
        notify.setOnClickListener(v -> subscribeSelected());
        writeResp.setOnClickListener(v -> writeSelected(false));
        writeNoResp.setOnClickListener(v -> writeSelected(true));
        dump.setOnClickListener(v -> readAllReadable());
        export.setOnClickListener(v -> exportLog());

        deviceList.setOnItemClickListener((parent, view, position, id) -> {
            String line = deviceAdapter.getItem(position);
            if (line == null) return;
            String addr = line.substring(line.lastIndexOf('[') + 1, line.lastIndexOf(']'));
            BluetoothDevice d = devices.get(addr);
            if (d != null) connect(d);
        });

        charList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= characteristics.size()) return;
            selectedCharacteristic = characteristics.get(position);
            selectedCharView.setText("Selected characteristic: " + selectedCharacteristic.getUuid());
            append("Selected " + selectedCharacteristic.getUuid() + " props=" + props(selectedCharacteristic));
        });
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(15f);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void ensurePermissions() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    private boolean hasBlePermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startScan() {
        if (!hasBlePermission()) {
            ensurePermissions();
            toast("Grant Bluetooth permissions, then scan again.");
            return;
        }
        if (adapter == null) {
            toast("Bluetooth LE is unavailable on this phone.");
            return;
        }
        if (!adapter.isEnabled()) {
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("BLE scanner unavailable.");
            return;
        }
        devices.clear();
        deviceAdapter.clear();
        append("Scanning for BLE devices; R8-US will be marked TARGET...");
        status.setText("Scanning…");
        scanner.startScan(scanCallback);
        main.postDelayed(() -> {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) {}
            status.setText(gatt == null ? "Scan complete" : "Connected");
            append("Scan stopped. Found " + devices.size() + " device(s).");
        }, 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String addr = d.getAddress();
            String name = null;
            try { name = d.getName(); } catch (SecurityException ignored) {}
            if ((name == null || name.isBlank()) && result.getScanRecord() != null)
                name = result.getScanRecord().getDeviceName();
            if (name == null) name = "(unnamed)";
            if (!devices.containsKey(addr)) {
                devices.put(addr, d);
                final String n = name;
                final int rssi = result.getRssi();
                main.post(() -> deviceAdapter.add((n.equalsIgnoreCase("R8-US") ? "★ TARGET " : "") + n + " RSSI " + rssi + " [" + addr + "]"));
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            main.post(() -> append("Scan failed: " + errorCode));
        }
    };

    private void connect(BluetoothDevice device) {
        if (!hasBlePermission()) return;
        disconnectGatt();
        selectedDevice = device;
        append("Connecting to " + safeName(device) + " [" + device.getAddress() + "]");
        status.setText("Connecting…");
        gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            main.post(() -> append("Connection state=" + newState + " status=" + statusCode));
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                main.post(() -> status.setText("Connected: " + safeName(g.getDevice())));
                try { g.requestMtu(247); } catch (SecurityException ignored) {}
                try { g.discoverServices(); } catch (SecurityException e) { main.post(() -> append("discoverServices permission error: " + e)); }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                main.post(() -> status.setText("Disconnected"));
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt g, int mtu, int statusCode) {
            main.post(() -> append("MTU=" + mtu + " status=" + statusCode));
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            main.post(() -> populateGatt(g, statusCode));
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int statusCode) {
            main.post(() -> append("READ " + c.getUuid() + " status=" + statusCode + " hex=" + hex(value) + " ascii=" + ascii(value)));
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            if (Build.VERSION.SDK_INT < 33) {
                byte[] v = c.getValue();
                main.post(() -> append("READ " + c.getUuid() + " status=" + statusCode + " hex=" + hex(v) + " ascii=" + ascii(v)));
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            main.post(() -> append("NOTIFY " + c.getUuid() + " hex=" + hex(value) + " ascii=" + ascii(value)));
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (Build.VERSION.SDK_INT < 33) {
                byte[] v = c.getValue();
                main.post(() -> append("NOTIFY " + c.getUuid() + " hex=" + hex(v) + " ascii=" + ascii(v)));
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            main.post(() -> append("WRITE result " + c.getUuid() + " status=" + statusCode));
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int statusCode) {
            main.post(() -> append("DESCRIPTOR write " + d.getUuid() + " status=" + statusCode));
        }
    };

    private void populateGatt(BluetoothGatt g, int statusCode) {
        append("Services discovered status=" + statusCode);
        characteristics.clear();
        charAdapter.clear();
        for (BluetoothGattService s : g.getServices()) {
            append("SERVICE " + s.getUuid());
            for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                characteristics.add(c);
                String line = c.getUuid() + "  [" + props(c) + "]";
                charAdapter.add(line);
                append("  CHAR " + line);
                for (BluetoothGattDescriptor d : c.getDescriptors()) append("    DESC " + d.getUuid());
            }
        }
        append("Choose a characteristic. Start with READ/NOTIFY; do not write unknown bytes.");
    }

    private void readSelected() {
        if (gatt == null || selectedCharacteristic == null) { toast("Connect and select a characteristic first."); return; }
        try {
            boolean ok = gatt.readCharacteristic(selectedCharacteristic);
            append("readCharacteristic queued=" + ok);
        } catch (SecurityException e) { append("Read permission error: " + e); }
    }

    private void subscribeSelected() {
        if (gatt == null || selectedCharacteristic == null) { toast("Connect and select a characteristic first."); return; }
        try {
            boolean local = gatt.setCharacteristicNotification(selectedCharacteristic, true);
            append("setCharacteristicNotification=" + local);
            BluetoothGattDescriptor cccd = selectedCharacteristic.getDescriptor(CCCD);
            if (cccd == null) {
                append("No CCCD (0x2902) on this characteristic.");
                return;
            }
            byte[] enable = (selectedCharacteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                    ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
            if (Build.VERSION.SDK_INT >= 33) {
                int r = gatt.writeDescriptor(cccd, enable);
                append("writeDescriptor queued result=" + r);
            } else {
                //noinspection deprecation
                cccd.setValue(enable);
                //noinspection deprecation
                append("writeDescriptor queued=" + gatt.writeDescriptor(cccd));
            }
        } catch (SecurityException e) { append("Subscribe permission error: " + e); }
    }

    private void writeSelected(boolean noResponse) {
        if (gatt == null || selectedCharacteristic == null) { toast("Connect and select a characteristic first."); return; }
        byte[] data;
        try { data = parseHex(hexInput.getText().toString()); }
        catch (IllegalArgumentException e) { toast(e.getMessage()); return; }
        if (data.length == 0) { toast("Enter at least one HEX byte."); return; }
        int writeType = noResponse ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
        try {
            append("WRITE request " + selectedCharacteristic.getUuid() + " type=" + (noResponse ? "NO_RESPONSE" : "DEFAULT") + " hex=" + hex(data));
            if (Build.VERSION.SDK_INT >= 33) {
                int r = gatt.writeCharacteristic(selectedCharacteristic, data, writeType);
                append("writeCharacteristic queue result=" + r);
            } else {
                //noinspection deprecation
                selectedCharacteristic.setWriteType(writeType);
                //noinspection deprecation
                selectedCharacteristic.setValue(data);
                //noinspection deprecation
                append("writeCharacteristic queued=" + gatt.writeCharacteristic(selectedCharacteristic));
            }
        } catch (SecurityException e) { append("Write permission error: " + e); }
    }

    private void readAllReadable() {
        if (gatt == null) { toast("Connect first."); return; }
        List<BluetoothGattCharacteristic> readable = new ArrayList<>();
        for (BluetoothGattCharacteristic c : characteristics) {
            if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) readable.add(c);
        }
        append("Queueing " + readable.size() + " readable characteristics sequentially...");
        readSequential(readable, 0);
    }

    private void readSequential(List<BluetoothGattCharacteristic> list, int i) {
        if (i >= list.size() || gatt == null) return;
        try {
            gatt.readCharacteristic(list.get(i));
            main.postDelayed(() -> readSequential(list, i + 1), 350);
        } catch (SecurityException e) { append("Read-all stopped: " + e); }
    }

    private void bondSelected() {
        if (selectedDevice == null) { toast("Select/connect a device first."); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
        append("createBond() requested for " + safeName(selectedDevice));
        selectedDevice.createBond();
    }

    private void requestMtu() {
        if (gatt == null) { toast("Connect first."); return; }
        try { append("requestMtu(247)=" + gatt.requestMtu(247)); }
        catch (SecurityException e) { append("MTU permission error: " + e); }
    }

    private void disconnectGatt() {
        if (gatt != null) {
            try { gatt.disconnect(); } catch (SecurityException ignored) {}
            gatt.close();
            gatt = null;
        }
        selectedCharacteristic = null;
        characteristics.clear();
        if (charAdapter != null) charAdapter.clear();
        if (selectedCharView != null) selectedCharView.setText("Selected characteristic: none");
        if (status != null) status.setText("Disconnected");
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? "(unnamed)" : n;
        } catch (SecurityException e) { return "(permission denied)"; }
    }

    private String props(BluetoothGattCharacteristic c) {
        int p = c.getProperties();
        List<String> out = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) out.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) out.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) out.add("WRITE_NO_RESP");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) out.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) out.add("INDICATE");
        return String.join("|", out);
    }

    private static byte[] parseHex(String input) {
        String s = input.replace("0x", "").replaceAll("[^0-9A-Fa-f]", "");
        if ((s.length() & 1) != 0) throw new IllegalArgumentException("HEX must contain complete byte pairs.");
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    private static String hex(byte[] data) {
        if (data == null) return "";
        StringBuilder b = new StringBuilder();
        for (byte x : data) b.append(String.format(Locale.US, "%02X ", x & 0xFF));
        return b.toString().trim();
    }

    private static String ascii(byte[] data) {
        if (data == null) return "";
        StringBuilder b = new StringBuilder();
        for (byte x : data) {
            int v = x & 0xFF;
            b.append(v >= 32 && v <= 126 ? (char) v : '.');
        }
        return b.toString();
    }

    private void append(String message) {
        String ts = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        log.append(ts).append("  ").append(message).append('\n');
        if (logView != null) logView.setText(log.toString());
    }

    private void exportLog() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "r8_ble_log_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
        startActivityForResult(i, REQ_EXPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os != null) os.write(log.toString().getBytes(StandardCharsets.UTF_8));
                toast("Log exported.");
            } catch (Exception e) {
                toast("Export failed: " + e.getMessage());
            }
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onDestroy() {
        disconnectGatt();
        super.onDestroy();
    }
}
