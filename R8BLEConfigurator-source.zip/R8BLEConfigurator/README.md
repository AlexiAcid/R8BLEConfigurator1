# R8 BLE Configurator

Android BLE diagnostic/configuration app aimed at the 2026 iSinwheel R8 advertising as `R8-US`.

## What v0.1 does

- Scans for nearby BLE devices and highlights `R8-US`.
- Connects over BLE GATT.
- Requests MTU 247 and enumerates every service, characteristic and descriptor.
- Shows READ / WRITE / WRITE_NO_RESP / NOTIFY / INDICATE properties.
- Reads individual characteristics.
- Subscribes to notifications/indications via CCCD.
- Reads all readable characteristics sequentially.
- Sends an explicitly entered HEX payload to a selected writable characteristic.
- Exports a timestamped session log.
- Can request system bonding if the controller requires it.

## Important

The R8's private BLE protocol is not publicly documented. The raw write function is deliberately not populated with guessed commands. Unknown writes can alter safety-critical controller parameters. First use READ, Subscribe and Export Log to identify the protocol.

## Build

Open the project in Android Studio (Ladybug or newer is fine), allow Gradle sync, then Build > Build APK(s).

The project targets Android 15 / API 35 and requires Android 8.0+.

## First test on the bike

1. Turn the R8 on and keep the official iSinwheel app fully closed so it cannot hold the BLE connection.
2. Open R8 BLE Configurator and grant Nearby devices/Bluetooth permission.
3. Tap **Scan R8-US**.
4. Tap the row marked **TARGET R8-US**.
5. Wait for `Services discovered` in the log.
6. Tap **Read all readable**.
7. Select every characteristic with `NOTIFY` or `INDICATE` and tap **Subscribe**.
8. Operate one bike control at a time (lights, assist/mode, etc.) while watching the log.
9. Tap **Export log** and share that log for command mapping.

Once a write protocol is identified, named controls such as speed limit can be added instead of entering raw HEX.
